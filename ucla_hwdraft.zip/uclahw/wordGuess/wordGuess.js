$(document).ready(function() {
    var min = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "Ñ", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];

    var buttons = [];
    var letra = "";
    var longitud;
    var palabra = "";
    var cadena = [];
    var uppercase = "";
    var numToMatch = 0;
    var stringword = "";
    var wrong = 6;
  
    $(".titulo").empty();
    $(".draw").text("Lets play");
    $("button#btn1").attr("disabled", false);
      //setCharAt funcion to search the letters
    function setCharAt(str, index, chr) {
        if (index > str.length - 1) return str;
        return str.substr(0, index) + chr + str.substr(index + 1);
    }
      //generate keyboard
    if ($(".keyboard").empty) {
        for (var i = 0; i < min.length; i++) {
            buttons.push('<button>' + min[i] + '</button>');
        }
        $(".keyboard").html(buttons.join(""));
    }
      //set button && input(#word1) validate
    $("#btn1").click(function() {
        if ($("#word1").val() == "") {
            $("#required").text("Empty");
        } else {
            $("#required").text("");
            $("button").attr("disabled", false);
            cadena.push($("#word1").val().split(""));
            longitud = $("#word1").val().length;
            palabra = $("#word1").val();
            uppercase = palabra.toUpperCase();
            var cont = 0;
            while (cont < longitud) {
                if (palabra.charAt(cont) == " ") {
                    $("#word").append(" ");
                } else {
                    $("#word").append("-");
                }
                cont++;
            }
            $("#word1").val("");
        }
    });
      //clear button
    $("#btn2").click(function() {
        $(".titulo").empty();
        palabra = "";
        uppercase = "";
        cadena = [];
        $("button").removeClass("good");
        $("button").removeClass("wrong");
        $(".draw").text("Lets play");
        wrong = 6;
        $("button").attr("disabled", true);
        $("button#btn1").attr("disabled", false);
    });
      //keyboard buttons
    $("button").click(function() {
        letra = $(this).text();
        if ((letra == "Set") || (letra == "Clear")) {} 
      else {
            $(this).attr("disabled", true);
            console.log(letra);
            console.log(uppercase);
            if (uppercase.includes(letra)) {
                var indices = [];
                for (var i = 0; i < uppercase.length; i++) {
                    if (uppercase[i] === letra)
                        indices.push(i);
                }
                for (var j = 0; j < indices.length; j++) {
                    numToMatch = indices[j];
                    stringword = $("#word").html();
                    stringword = setCharAt(stringword, numToMatch, letra);
                    $("#word").text(stringword);
                }
                if (stringword.includes("-")) {} 
              else {
                    $(".draw").text("YOU WON");
                    $("button").attr("disabled", true);
                    $("button#btn1").attr("disabled", false);
                    $("button#btn2").attr("disabled", false);
                }
                $(this).addClass("good");
            } else {
                $(this).addClass("wrong");
                wrong--;
                $(".draw").text("Lifes left " + wrong);
                if (wrong <= 0) {
                    wrong = 0;
                    $(".draw").text("YOU LOST");
                    if(($(".draw").text()) == "YOU LOST"){
                      $("#word").replaceWith("<p class='titulo'>" + uppercase + "</p>");
                      $("button").attr("disabled", true);
                      $("button#btn1").attr("disabled", false);
                      $("button#btn2").attr("disabled", false);
                    }
                }
            }
        }
    });
});